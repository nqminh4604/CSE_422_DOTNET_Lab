﻿using DPLibraryManagement.Models;
using DPLibraryManagement.Services;
using DPLibraryManagement.Strategies;

class Program
{
    static void Main()
    {
        // Singleton Database Connection
        var db = DatabaseConnection.Instance;
        db.Connect();

        // Factory Pattern - Creating Documents
        Document book = DocumentFactory.CreateDocument("book", "C# Programming");
        Document magazine = DocumentFactory.CreateDocument("magazine", "Tech Monthly");
        Document newspaper = DocumentFactory.CreateDocument("newspaper", "Daily News");

        book.DisplayInfo();
        magazine.DisplayInfo();
        newspaper.DisplayInfo();

        // Observer Pattern - User Notification
        LibraryNotifier notifier = new LibraryNotifier();
        User user1 = new User("Alice");
        notifier.Subscribe(user1);
        notifier.Notify("A new book has been added to the library.");

        // Strategy Pattern - Loan Fee Calculation with User Input
        LoanFeeCalculator calculator = new LoanFeeCalculator();
        Console.Write("Enter loan fee rate for book: ");
        decimal bookRate = Convert.ToDecimal(Console.ReadLine());
        calculator.SetStrategy(new BookLoanFee());
        Console.WriteLine("Book Loan Fee for 5 days: " + calculator.GetFee(5, bookRate));
    }
}
