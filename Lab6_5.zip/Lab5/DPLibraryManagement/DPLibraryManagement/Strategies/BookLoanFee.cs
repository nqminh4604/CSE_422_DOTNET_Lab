﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPLibraryManagement.Interfaces;

namespace DPLibraryManagement.Strategies
{
    public class BookLoanFee : ILoanFeeStrategy
    {
        public decimal CalculateFee(int days, decimal rate) => days * rate;
    }
}
