﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPLibraryManagement.Interfaces;

namespace DPLibraryManagement.Services
{
    public class LoanFeeCalculator
    {
        private ILoanFeeStrategy _strategy;
        public void SetStrategy(ILoanFeeStrategy strategy) => _strategy = strategy;
        public decimal GetFee(int days, decimal rate)
        {
            if (_strategy == null)
            {
                throw new InvalidOperationException("Loan fee strategy is not set.");
            }
            return _strategy.CalculateFee(days, rate);
        }
    }
}
