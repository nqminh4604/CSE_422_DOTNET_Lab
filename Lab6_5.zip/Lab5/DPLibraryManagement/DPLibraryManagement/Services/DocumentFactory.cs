﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPLibraryManagement.Models;

namespace DPLibraryManagement.Services
{
    public class DocumentFactory
    {
        public static Document CreateDocument(string type, string title)
        {
            return type.ToLower() switch
            {
                "book" => new Book { Title = title },
                "magazine" => new Magazine { Title = title },
                "newspaper" => new Newspaper { Title = title },
                _ => throw new ArgumentException("Invalid document type")
            };
        }
    }
}
