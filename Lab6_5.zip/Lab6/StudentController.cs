using Microsoft.AspNetCore.Mvc;

public interface INamedEntity
{
    string Name { get; set; }
}

[ApiController]
[Route("api/[controller]")]
public class BaseController<T> : ControllerBase where T : class, INamedEntity, new()
{
    [HttpPost]
    public IActionResult Create([FromBody] T entity)
    {
        if (entity == null || string.IsNullOrEmpty(entity.Name))
            return BadRequest("Invalid data");

        return Ok($"{typeof(T).Name} {entity.Name} created successfully.");
    }
}

public class Student : INamedEntity
{
    public int Id { get; set; }
    public string Name { get; set; }
}

public class Teacher : INamedEntity
{
    public int Id { get; set; }
    public string Name { get; set; }
}

public class StudentController : BaseController<Student> { }

public class TeacherController : BaseController<Teacher> { }
