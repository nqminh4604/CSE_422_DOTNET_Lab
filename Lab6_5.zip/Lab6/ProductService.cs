public interface IDataService<T>
{
    string GetData(int id);
}

public class ProductService : IDataService<string>
{
    public string GetData(int productId)
    {
        Console.WriteLine("Fetching from database...");
        return $"Product {productId}"; // Simulated DB fetch
    }
}

public class UserService : IDataService<string>
{
    public string GetData(int userId)
    {
        Console.WriteLine("Fetching from database...");
        return $"User {userId}"; // Simulated DB fetch
    }
}

public class CacheDecorator<T> : IDataService<T>
{
    private readonly IDataService<T> _innerService;
    private readonly Dictionary<int, T> _cache = new Dictionary<int, T>();

    public CacheDecorator(IDataService<T> innerService)
    {
        _innerService = innerService;
    }

    public T GetData(int id)
    {
        if (_cache.ContainsKey(id))
        {
            Console.WriteLine("Fetching from cache...");
            return _cache[id];
        }

        T data = _innerService.GetData(id);
        _cache[id] = data;
        return data;
    }
}

class Program
{
    static void Main()
    {
        IDataService<string> productService = new CacheDecorator<string>(new ProductService());
        IDataService<string> userService = new CacheDecorator<string>(new UserService());

        Console.WriteLine(productService.GetData(1)); // Fetches from DB
        Console.WriteLine(productService.GetData(1)); // Fetches from Cache

        Console.WriteLine(userService.GetData(2)); // Fetches from DB
        Console.WriteLine(userService.GetData(2)); // Fetches from Cache
    }
}

