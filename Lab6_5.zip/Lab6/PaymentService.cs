public interface IPaymentStrategy
{
    void ProcessPayment(double amount);
}

public class CreditCardPayment : IPaymentStrategy
{
    public void ProcessPayment(double amount)
    {
        Console.WriteLine($"Processing credit card payment: {amount}");
    }
}

public class PayPalPayment : IPaymentStrategy
{
    public void ProcessPayment(double amount)
    {
        Console.WriteLine($"Processing PayPal payment: {amount}");
    }
}

public class CryptoPayment : IPaymentStrategy
{
    public void ProcessPayment(double amount)
    {
        Console.WriteLine($"Processing cryptocurrency payment: {amount}");
    }
}

public class PaymentFactory
{
    public static IPaymentStrategy GetPaymentMethod(string method)
    {
        return method.ToLower() switch
        {
            "creditcard" => new CreditCardPayment(),
            "paypal" => new PayPalPayment(),
            "crypto" => new CryptoPayment(),
            _ => throw new ArgumentException("Invalid payment method")
        };
    }
}

public class PaymentService
{
    private readonly IPaymentStrategy _paymentStrategy;

    public PaymentService(IPaymentStrategy paymentStrategy)
    {
        _paymentStrategy = paymentStrategy;
    }

    public void ProcessPayment(double amount)
    {
        _paymentStrategy.ProcessPayment(amount);
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Enter payment method (CreditCard, PayPal, Crypto): ");
        string method = Console.ReadLine();

        try
        {
            IPaymentStrategy paymentStrategy = PaymentFactory.GetPaymentMethod(method);
            PaymentService paymentService = new PaymentService(paymentStrategy);

            paymentService.ProcessPayment(100.00);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
