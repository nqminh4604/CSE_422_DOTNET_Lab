using System;
using System.Reflection;

public class Logger
{
    public void Log(object logData)
    {
        Type type = logData.GetType();
        PropertyInfo[] properties = type.GetProperties();

        string logMessage = $"{type.Name}: ";
        foreach (var prop in properties)
        {
            object value = prop.GetValue(logData);
            logMessage += $"{prop.Name}={value}, ";
        }

        Console.WriteLine(logMessage.TrimEnd(',', ' '));
    }
}

public class UserAction
{
    public string Username { get; set; }
    public string Action { get; set; }
}

public class Transaction
{
    public int TransactionId { get; set; }
    public double Amount { get; set; }
}

public class ErrorLog
{
    public string ErrorMessage { get; set; }
    public DateTime Timestamp { get; set; }
}

class Program
{
    static void Main()
    {
        Logger logger = new Logger();

        logger.Log(new UserAction { Username = "Alice", Action = "Login" });
        logger.Log(new Transaction { TransactionId = 12345, Amount = 250.75 });
        logger.Log(new ErrorLog { ErrorMessage = "Null reference exception", Timestamp = DateTime.Now });
    }
}
