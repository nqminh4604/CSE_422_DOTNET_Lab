using System;
using System.Collections.Generic;
using System.Data.SqlClient;

public class GenericRepository<T> where T : new()
{
    private readonly SqlConnection _connection;

    public GenericRepository(SqlConnection connection)
    {
        _connection = connection;
    }

    public List<T> GetAll(string tableName)
    {
        var items = new List<T>();
        var command = new SqlCommand($"SELECT * FROM {tableName}", _connection);
        var reader = command.ExecuteReader();

        var properties = typeof(T).GetProperties();
        while (reader.Read())
        {
            var item = new T();
            foreach (var prop in properties)
            {
                prop.SetValue(item, reader[prop.Name]);
            }
            items.Add(item);
        }

        return items;
    }
}

public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
}

public class Teacher
{
    public int Id { get; set; }
    public string Name { get; set; }
}

public class StudentRepository : GenericRepository<Student>
{
    public StudentRepository(SqlConnection connection) : base(connection) { }

    public List<Student> GetAllStudents()
    {
        return GetAll("Students");
    }
}

public class TeacherRepository : GenericRepository<Teacher>
{
    public TeacherRepository(SqlConnection connection) : base(connection) { }

    public List<Teacher> GetAllTeachers()
    {
        return GetAll("Teachers");
    }
}

class Program
{
    static void Main()
    {
        using (var connection = new SqlConnection("your_connection_string"))
        {
            connection.Open();
            var studentRepo = new StudentRepository(connection);
            var teacherRepo = new TeacherRepository(connection);

            var students = studentRepo.GetAllStudents();
            var teachers = teacherRepo.GetAllTeachers();

            foreach (var student in students)
                Console.WriteLine($"Student: {student.Id} - {student.Name}");

            foreach (var teacher in teachers)
                Console.WriteLine($"Teacher: {teacher.Id} - {teacher.Name}");
        }
    }
}
