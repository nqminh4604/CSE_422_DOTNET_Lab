﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockTestCSE422.Assignment2
{
    interface INotification
    {
        void SendNotification(string message);
    }
}
